# KiloWare 32K Full Spec Summary

Full 32K extension: 4 models x 27 workloads = 108 rows. Specs are extended from the verified 16K workload set and keep the final question after the extended context.

- rows: 108
- specs: 4
- CSV: `longctx32/longctx32_spec_summary.csv`

| model | length | rows | min | median | max |
|---|---:|---:|---:|---:|---:|
| qwen2p5_7b_instruct | 32k | 27 | 32467 | 32487 | 32498 |
| mistral_7b_instruct_v0p3 | 32k | 27 | 32442 | 32504 | 32549 |
| llama3p1_8b_instruct | 32k | 27 | 32489 | 32505 | 32522 |
| qwen2p5_14b_instruct | 32k | 27 | 32450 | 32467 | 32530 |
