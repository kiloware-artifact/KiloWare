# KiloWare 32K Full Execution Plan

Full 32K tracegen plan: 4 models x 27 workloads = 108 rows.

- CSV: `longctx32_text_execution_plan.csv`

| model | length | rows | min | median | max | spec |
|---|---:|---:|---:|---:|---:|---|
| qwen2p5_7b_instruct | 32k | 27 | 32467 | 32487 | 32498 | `specs/32k/qwen2p5_7b_instruct_32k_all_tasks.json` |
| mistral_7b_instruct_v0p3 | 32k | 27 | 32442 | 32504 | 32549 | `specs/32k/mistral_7b_instruct_v0p3_32k_all_tasks.json` |
| llama3p1_8b_instruct | 32k | 27 | 32489 | 32505 | 32522 | `specs/32k/llama3p1_8b_instruct_32k_all_tasks.json` |
| qwen2p5_14b_instruct | 32k | 27 | 32450 | 32467 | 32530 | `specs/32k/qwen2p5_14b_instruct_32k_all_tasks.json` |
